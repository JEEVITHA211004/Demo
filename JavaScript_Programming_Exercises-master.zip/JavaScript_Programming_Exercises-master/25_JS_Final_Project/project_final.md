# Final Project 1

## Create the following animation using (HTML, CSS, JS)

![countries_final_project](https://github.com/Asabeneh/30-Days-Of-JavaScript/raw/master/images/projects/dom_mini_project_countries_object_day_10.1.gif)


# Final Project 2

## Validate the following form using regex.

### Input Page Design & Instructions

![final_input_page](https://github.com/Asabeneh/30-Days-Of-JavaScript/raw/master/images/projects/dom_mini_project_form_validation_day_10.2.1.png)

### Expected Output Page

![final_output_page](https://github.com/Asabeneh/30-Days-Of-JavaScript/raw/master/images/projects/dom_mini_project_form_validation_day_10.2.png)

