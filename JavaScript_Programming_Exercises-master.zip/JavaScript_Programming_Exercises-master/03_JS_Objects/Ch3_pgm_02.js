// Using prefixes to tell book variables apart

var book1Title = "The Hobbit";
var book1Author = "J.R.R.Tolkien";

var book2Title = "Northern Lights";
var book2Author = "Philip Pullman";

var book3Title = "The Adventures of Tom Sawyer";
var book3Author = "Mark Twain";

console.log("There are three books so far...");
console.log(book1Title + " by " + book1Author);
console.log(book2Title + " by " + book2Author);
console.log(book3Title + " by " + book3Author);



/* Further Adventures
 *
 * 1) Add a fourth book.
 *
 * 2) Update the messages to include the new book.
 *
 */