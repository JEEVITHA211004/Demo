# Develop a small application which calculate a weight of an object in a certain planet. The gif image is not complete check the video in the starter file.

Sample Project GIF Image:

![solar_system_project](https://github.com/Asabeneh/30-Days-Of-JavaScript/raw/master/images/projects/dom_min_project_solar_system_day_4.1.gif)


To download images, click the below link:

https://github.com/Asabeneh/30-Days-Of-JavaScript/tree/master/24_Day_Project_solar_system/24_day_starter/images

To download background video, click the below link:

https://github.com/Asabeneh/30-Days-Of-JavaScript/tree/master/24_Day_Project_solar_system/24_day_starter/design