# Visualize the ten most populated countries and the ten most spoken languages in the world using DOM(HTML, CSS, JS)

![world-countries-data](https://github.com/Asabeneh/30-Days-Of-JavaScript/raw/master/images/projects/dom_min_project_bar_graph_day_5.1.gif)

![world-countries-languages](https://github.com/Asabeneh/30-Days-Of-JavaScript/raw/master/images/projects/dom_min_project_bar_graph_day_5.1.png)