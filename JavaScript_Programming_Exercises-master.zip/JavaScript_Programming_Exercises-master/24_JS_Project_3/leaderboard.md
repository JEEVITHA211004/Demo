# Create the following using HTML, CSS, and JavaScript

![project_leaderboard](https://github.com/Asabeneh/30-Days-Of-JavaScript/raw/master/images/projects/dom_mini_project_leaderboard_day_8.1.gif)