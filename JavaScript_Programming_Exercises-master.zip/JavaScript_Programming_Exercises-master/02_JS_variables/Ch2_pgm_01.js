// Declaring a variable

var score;

/* Further Adventures
 *
 * 1) Delete the semicolon at after the word score.
 *    JS Bin should complain and show an error message.
 *    Take a look at the message.
 *
 * 2) Add the semicolon back after the word score.
 *    The semicolon shows the end of the statement.
 *
 * 3) Declare two more variables.
 *
 */